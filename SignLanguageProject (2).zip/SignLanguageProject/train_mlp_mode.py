import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.utils.class_weight import compute_class_weight
from tensorflow import keras
from tensorflow.keras import layers
import joblib

# ===============================
# 🔹 غيري فقط هذا
# ===============================
MODE_NAME = "letters"  # letters / numbers / word

# ===============================
# Load data
# ===============================
df = pd.read_csv(f"C:\\SignLanguage1\\{MODE_NAME}_landmarks.csv")

X = df.drop("label", axis=1).values
y = df["label"].values

# ===============================
# Encode labels
# ===============================
le = LabelEncoder()
y_encoded = le.fit_transform(y)

# ===============================
# Scale features
# ===============================
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ===============================
# Train / Test split
# ===============================
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y_encoded, test_size=0.2, random_state=42
)

# ===============================
# Compute Class Weights
# ===============================
class_weights = compute_class_weight(
    class_weight="balanced",
    classes=np.unique(y_train),
    y=y_train
)

class_weights_dict = dict(enumerate(class_weights))

# ===============================
# Build MLP model
# ===============================
model = keras.Sequential([
    layers.Dense(256, activation="relu", input_shape=(63,)),
    layers.BatchNormalization(),
    layers.Dropout(0.4),

    layers.Dense(128, activation="relu"),
    layers.BatchNormalization(),
    layers.Dropout(0.3),

    layers.Dense(64, activation="relu"),
    layers.Dropout(0.2),

    layers.Dense(len(le.classes_), activation="softmax")
])

model.compile(
    optimizer=keras.optimizers.Adam(learning_rate=0.001),
    loss="sparse_categorical_crossentropy",
    metrics=["accuracy"]
)

# ===============================
# Callbacks
# ===============================
early_stop = keras.callbacks.EarlyStopping(
    monitor="val_loss",
    patience=10,
    restore_best_weights=True
)

reduce_lr = keras.callbacks.ReduceLROnPlateau(
    monitor="val_loss",
    factor=0.5,
    patience=5,
    min_lr=1e-5
)

# ===============================
# Train
# ===============================
history = model.fit(
    X_train, y_train,
    epochs=100,
    batch_size=32,
    validation_split=0.2,
    class_weight=class_weights_dict,
    callbacks=[early_stop, reduce_lr]
)

# ===============================
# Evaluate
# ===============================
loss, acc = model.evaluate(X_test, y_test)
print(f"\nTest Accuracy: {acc:.4f}")

# ===============================
# Save everything
# ===============================
model.save(f"C:\\SignLanguage1\\{MODE_NAME}_mlp_model.h5")
joblib.dump(scaler, f"C:\\SignLanguage1\\{MODE_NAME}_scaler.save")
joblib.dump(le, f"C:\\SignLanguage1\\{MODE_NAME}_label_encoder.save")

print("\nModel saved successfully!")